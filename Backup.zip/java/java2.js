$(window).on("load",function(){
	$(".loader_container").fadeOut(1000);
});
